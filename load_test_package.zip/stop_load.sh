#!/bin/bash

### variables
. ./load_env.sh

export STOP_LOG=stop.log
export TMP_DIR=tmp
export STOP_SCRIPT="scripts/stop_check.sh"

### clear the log file if it exists
if [ -f "$STOP_LOG" ]
then
  rm $STOP_LOG
fi

### sometimes heavy loads prevent or delay sessions from being
### killed so we need to verify and run the kill again sometimes
stop_cnt=1
while [ $stop_cnt -gt 0 ]
do


  ### generate the kill commands
  sqlplus -s $USER_NAME/$PW@$CONNECT_STRING <<EOF >>$STOP_LOG

  set heading off
  set feedback off
  set termout off

  spool stop_all.sql

  select 'alter system kill session ''' || sid || ',' || serial# || ',@' || inst_id || ''' immediate;'
  from gv\$session where module = 'Load Generator';

  spool off

EOF

  ###
  ### creating a seperate file for each kill command since
  ### they can sometimes take time to execute. This way we
  ### can run a bunch in parallel
  ###


  i=0
  while read LINE
  do
    i=$((i + 1))
    echo $LINE > $TMP_DIR/$i.sql
    echo 'exit;' >> $TMP_DIR/$i.sql
  
    nohup sqlplus -s $USER_NAME/$PW@$CONNECT_STRING @$TMP_DIR/$i.sql >$STOP_LOG 2>&1 &
  
  done < <( cat stop_all.sql)
  
    sleep 5
    stop_cnt=`$STOP_SCRIPT`
    echo "Sessions still being stopped... $stop_cnt"
done


### cleanup
rm stop_all.sql
rm $TMP_DIR/*
