#!/bin/bash

### load variables
. ./load_env.sh

### check if sessions are still initializing and echo that number
### to the calling module
sqlplus -s $USER_NAME/$PW@$CONNECT_STRING <<EOF

set feedback off

variable retval number;

DECLARE
  v_cnt number;
BEGIN

  select count(*) into v_cnt
    from gv\$session
   where module = 'Load Generator';

  :retval := v_cnt;

END;
/

exit :retval;
EOF

echo $?


