#!/bin/bash

### variables
. ./load_env.sh

export TEST_TABLE=$1

### run the load
sqlplus -s $USER_NAME/$PW@$CONNECT_STRING <<EOF

begin
  dbms_application_info.set_module( 'Load Generator', 'Running');
end;
/

begin
  loop
    insert /*+ append */ into $TEST_TABLE select * from $TEST_TABLE;
    rollback;
  end loop;
end;
/


EOF



