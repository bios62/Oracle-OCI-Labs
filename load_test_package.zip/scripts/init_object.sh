#!/bin/bash

### variables
. ./load_env.sh

export TEST_TABLE=$1

### drop the table if neccessary, create and load it
sqlplus -s $USER_NAME/$PW@$CONNECT_STRING <<EOF

set serveroutput on

-- if our test table doesn't exist, create it
-- otherwise drop and recreate
declare
  v_cnt number;
begin

  dbms_application_info.set_module( 'Load Generator', 'Initializing');

  select count(*) into v_cnt
    from user_tables
  where table_name = upper('$TEST_TABLE');

  if( v_cnt > 0) then
    execute immediate
    'drop table $TEST_TABLE';
    dbms_output.put_line('Dropped table $TEST_TABLE');
  end if;

  execute immediate
  'create table $TEST_TABLE tablespace $TABLESPACE as ' ||
  'select a.* from ' ||
   '(select * from all_objects where rownum <= 100) a, ' ||
   '(select * from all_objects where rownum <= 100) b, ' ||
   '(select * from all_objects where rownum <= 100) c, ' ||
   '(select * from all_objects where rownum <= 10) d';

   dbms_output.put_line('Created table $TEST_TABLE');
end;
/


EOF


