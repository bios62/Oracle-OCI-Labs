#!/bin/bash

### variables
. ./load_env.sh

export TEST_TABLE=$1

### run the load
sqlplus -s $USER_NAME/$PW@$CONNECT_STRING <<EOF

begin
  dbms_application_info.set_module( 'Load Generator', 'Running');
end;
/

declare
  TYPE MyTableType IS REF CURSOR;
  v_cursor    MyTableType;
  v_inst varchar2(32);
  v_db_link varchar2(32);
  v_sql varchar2(256);
  v_rec $TEST_TABLE%ROWTYPE;
begin
  select instance_number into v_inst from v\$instance;

  if( v_inst = 1) then
    v_db_link := 'kurt_node2';
  else
    v_db_link := 'kurt_node1';
  end if;


  v_sql := 'SELECT * FROM $TEST_TABLE@' || v_db_link;
  open v_cursor FOR v_sql;

  loop
    fetch v_cursor INTO v_rec;
    exit when v_cursor%NOTFOUND;
  end loop;

  close v_cursor;
end;
/



EOF



