#!/bin/bash

### variables
. ./load_env.sh

### get system password
echo -n "System Password:"
read -s SYSTEM_PW
echo

### drop the table if neccessary, create and load it
sqlplus -s system/$SYSTEM_PW@$CONNECT_STRING <<EOF

set serveroutput on

-- if our test user doesn't exist, create it
declare
  v_cnt number;
begin

  select count(*) into v_cnt
    from dba_users
  where username = upper('$USER_NAME');

  if( v_cnt = 0) then
    execute immediate
    'create user $USER_NAME identified by "$PW"';

    execute immediate
    'grant dba to $USER_NAME';
  end if;

end;
/


EOF


