#!/bin/bash

### variables
. ./load_env.sh


### test table name
export LOAD_SCRIPT=scripts/load_object.sh

### clear the log file if it exists
if [ -f "$OUT_LOG" ]
then
  rm $OUT_LOG
fi

### loop and launch iterations
for (( c=$1; c<=$2; c++ ))
do
  #echo "starting $TEST_TABLE$c"
  nohup ./$LOAD_SCRIPT $TEST_TABLE$c >>$OUT_LOG 2>&1 & 
done

