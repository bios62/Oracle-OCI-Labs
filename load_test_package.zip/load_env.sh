#!/bin/bash

###
### Variables
###

export TABLESPACE=<test_tablespace>
export USER_NAME=<test_user>
export PW=<test_user_pw>
export CONNECT_STRING=//<host_or_scanvip>/<service>
### test table name prefix
export TEST_TABLE=large_block
export MAX_TABLES=300
export OUT_LOG=load.log

