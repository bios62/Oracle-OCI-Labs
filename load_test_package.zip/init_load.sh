#!/bin/bash

### variables
. ./load_env.sh

### files and settings for this script
export BATCH_SIZE=50
export CHECK_SCRIPT="scripts/init_check.sh"
export USER_SCRIPT="scripts/init_user.sh"
export OBJECT_SCRIPT="scripts/init_object.sh"

### clear the log file if it exists
if [ -f "$OUT_LOG" ]
then
  rm $OUT_LOG
fi

### create our test user
$USER_SCRIPT | tee $OUT_LOG

### loop and launch iterations
### if the number of iterations is > BATCH_SIZE, then let's sleep
### in batches of BATCH_SIZE to avoid excessive contention in the build process
batch_iteration=1
for (( c=1; c<=$MAX_TABLES; c++ ))
do
  #echo "Initializing $TEST_TABLE$c"
  nohup ./$OBJECT_SCRIPT $TEST_TABLE$c >>$OUT_LOG 2>&1 & 

  if [ $(( c % BATCH_SIZE )) -eq 0 ]
  then
    ### check the status of our initialization
    init_cnt=1
    while [ $init_cnt -gt 0 ]
    do 
      sleep 5
      init_cnt=`$CHECK_SCRIPT`
      echo "Objects still being initialized... $(( MAX_TABLES - (BATCH_SIZE * batch_iteration) + init_cnt))"
    done
    batch_iteration=$(( batch_iteration + 1 ))
  fi
done

### check the status of our initialization
### some duplicate code here, but was eaier to handle this way
init_cnt=1
while [ $init_cnt -gt 0 ]
do 
  sleep 5
  init_cnt=`$CHECK_SCRIPT`
  echo "Objects still being initialized... $init_cnt"
done

