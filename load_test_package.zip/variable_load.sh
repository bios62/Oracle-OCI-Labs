#!/usr/bin/perl

###
### Set these variables for your needs
##

### how long you want the test to run in hourse:minutes
$runtime = "00:15";


### Adjust your vaiable loads here
###
### RunTime = how ling this load will run in hours:minutes
### UserCount = how many user connections
### SleepTime = how many seconds to sleep before running the load, if needed
###
###              RunTime  UserCount  SleepTime
@load_list = ( ["00:05", 25,         0],
               ["00:05", 50,         0],
               ["00:05", 100,        0] );
###
### end variables
###

### calculate in seconds how long our load will be running
($run_hours, $run_minutes) = split(/:/, $runtime);
$end_time = time() + ($run_hours * 3600) + ($run_minutes * 60);

select STDERR; $| = 1;  # make unbuffered
select STDOUT; $| = 1;  # make unbuffered

### run each load in order until time runs out
while( $end_time > time() ) {
  for $i ( 0 .. $#load_list ) {
    print "Sleeping for $load_list[$i][2] seconds\n" if( $load_list[$i][2] > 0);
    sleep $load_list[$i][2];

    print "\nRun Time   : $load_list[$i][0]\nUser Count : $load_list[$i][1]\n\n";
    system("start_load.sh 1 $load_list[$i][1]");

    ### calculate in seconds how long our load will be running
    ($run_hours, $run_minutes) = split(/:/, $load_list[$i][0]);
    $sleep_time = ($run_hours * 3600) + ($run_minutes * 60);

    sleep $sleep_time;

    print "Stopping load...\n";
    system("stop_load.sh");

  }
}

print "End of variable load test\n";
